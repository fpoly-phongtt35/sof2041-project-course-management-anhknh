/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edusys_utils;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

/**
 *
 * @author Admin
 */
public class JdbcHelper {
    public static final String HOSTNAME = "LAPTOP-HDVM3L64";
    public static final String PORT = "1433";
    public static final String DBNAME = "Polypro";
    public static final String USERNAME = "sa";
    public static final String PASSWORD = "knha1207";
    public static Connection getConnection() {

        String connectionUrl = "jdbc:sqlserver://" + HOSTNAME + ":" + PORT + ";"
                + "databaseName=" + DBNAME + ";encrypt=true;trustServerCertificate=true;";
        try {
            return DriverManager.getConnection(connectionUrl, USERNAME, PASSWORD);
        } 
        catch (SQLException e) {
            e.printStackTrace(System.out);
        }
        return null;
    }
    public static PreparedStatement  getStmt(String sql, Object... args) throws SQLException {
        PreparedStatement pstmt = null;
        if(sql.trim().startsWith("{")){
            pstmt = getConnection().prepareCall(sql);
        } else {
            pstmt = getConnection().prepareStatement(sql);
        }
        for(int i = 0; i < args.length; i++){
            pstmt.setObject(i + 1, args[i]);
        }
        return pstmt;
    }
    public static int update(String sql, Object... args) {
        try {
            PreparedStatement stmt = getStmt(sql, args);
            try {
                return stmt.executeUpdate();
            } finally {
                stmt.getConnection().close();
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
    public static ResultSet query (String sql, Object... args) {
        try {
            PreparedStatement stmt = getStmt(sql, args);
            return stmt.executeQuery();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
    public static Object value (String sql, Object... args) {
        try {
            ResultSet rs = query(sql, args);
            if(rs.next()) {
                return  rs.getObject(0);
            }
            rs.getStatement().getConnection().close();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        return null;
    }
}

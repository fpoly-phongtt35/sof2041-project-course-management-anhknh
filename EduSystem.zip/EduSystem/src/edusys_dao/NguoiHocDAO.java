/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edusys_dao;

import edusys_entity.NguoiHoc;
import edusys_utils.JdbcHelper;
import java.util.ArrayList;
import java.util.List;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;

/**
 *
 * @author Admin
 */
public class NguoiHocDAO extends EduSysDAO<NguoiHoc, String> {

    final String INSERT_SQL = "INSERT INTO NGUOIHOC(MANH, HOTEN, NGAYSINH, GIOITINH, DIENTHOAI, EMAIL, MANV, NGAYDK) VALUES(?,?,?,?,?,?,?,?)";
    final String UPDATE_SQL = "UPDATE NGUOIHOC SET HOTEN = ?, NGAYSINH = ?, GIOITINH = ?, DIENTHOAI = ?, EMAIL = ?, MANV = ?, NGAYDK = ? WHERE MANH = ?";
    final String DELETE_SQL = "DELETE FROM NGUOIHOC WHERE MANH = ?";
    final String SELECT_ALL_SQL = "SELECT * FROM NGUOIHOC";
    final String SELECT_BY_ID_SQL = "SELECT * FROM NGUOIHOC WHERE MANH = ?";

    @Override
    public void insert(NguoiHoc entity) {
        JdbcHelper.update(INSERT_SQL, entity.getMaNH(), entity.getHoTen(), entity.getNgaySinh(), entity.getGioiTinh(), entity.getDienThoai(), entity.getEmail(), entity.getMaNV(), entity.getNgayDK());
    }

    @Override
    public void update(NguoiHoc entity) {
        JdbcHelper.update(UPDATE_SQL, entity.getHoTen(), entity.getNgaySinh(), entity.getGioiTinh(), entity.getDienThoai(), entity.getEmail(), entity.getMaNV(), entity.getNgayDK(), entity.getMaNH());
    }

    @Override
    public void delete(String id) {
        JdbcHelper.update(DELETE_SQL, id);
    }

    @Override
    public List<NguoiHoc> selectAll() {
        return selectBySql(SELECT_ALL_SQL);
    }

    @Override
    public NguoiHoc selectById(String id) {
        List<NguoiHoc> list = selectBySql(SELECT_BY_ID_SQL, id);
        if (list.isEmpty()) {
            return null;
        }
        return list.get(0);
    }

    @Override
    public List<NguoiHoc> selectBySql(String sql, Object... args) {
        List<NguoiHoc> list = new ArrayList<>();
        SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
        try {
            ResultSet rs = JdbcHelper.query(sql, args);
            while (rs.next()) {
                NguoiHoc entity = new NguoiHoc();
                entity.setMaNH(rs.getString("MaNH"));
                entity.setHoTen(rs.getString("HoTen"));
                entity.setNgaySinh(formatter.parse(rs.getString("NgaySinh")));
                if (rs.getString("GioiTinh").equals(0)) {
                    entity.setGioiTinh(false);

                } else {
                    entity.setGioiTinh(true);
                }
                entity.setDienThoai(rs.getString("DienThoai"));
                entity.setEmail(rs.getString("Email"));
                entity.setMaNV(rs.getString("MaNV"));
                entity.setNgayDK(formatter.parse(rs.getString("NgayDK")));
                list.add(entity);
            }
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        return list;
    }

}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edusys_dao;

import edusys_entity.KhoaHoc;
import edusys_utils.JdbcHelper;
import java.util.ArrayList;
import java.util.List;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;

/**
 *
 * @author Admin
 */
public class KhoaHocDAO extends EduSysDAO<KhoaHoc, Integer>{
    final String INSERT_SQL = "INSERT INTO KHOAHOC(MAKH, MACD, HOCPHI, THOILUONG, NGAYKG, GHICHU, MANV, NGAYTAO) VALUES(?,?,?,?,?,?,?,?)";
    final String UPDATE_SQL = "UPDATE KHOAHOC SET MACD = ?, HOCPHI = ?, THOILUONG = ?, NGAYKG = ?, GHICHU = ?, MANV = ?, NGAYTAO = ? WHERE MAKH = ?";
    final String DELETE_SQL = "DELETE FROM KHOAHOC WHERE MAKH = ?";
    final String SELECT_ALL_SQL = "SELECT * FROM KHOAHOC";
    final String SELECT_BY_ID_SQL = "SELECT * FROM KHOAHOC WHERE MAKH = ?";
    @Override
    public void insert(KhoaHoc entity) {
        JdbcHelper.update(INSERT_SQL, entity.getMaKH(), entity.getMaCD(), entity.getHocPhi(),entity.getThoiLuong(),entity.getNgayKG(), entity.getGhiChu(), entity.getMaNV(), entity.getNgayTao());
    }

    @Override
    public void update(KhoaHoc entity) {
        JdbcHelper.update(UPDATE_SQL, entity.getMaCD(), entity.getHocPhi(),entity.getThoiLuong(),entity.getNgayKG(), entity.getGhiChu(), entity.getMaNV(), entity.getNgayTao(), entity.getMaKH());
    }

    @Override
    public void delete(Integer id) {
        JdbcHelper.update(DELETE_SQL, id);
    }

    @Override
    public List<KhoaHoc> selectAll() {
        return selectBySql(SELECT_ALL_SQL);
    }

    @Override
    public KhoaHoc selectById(Integer id) {
        List<KhoaHoc> list = selectBySql(SELECT_BY_ID_SQL, id);
        if(list.isEmpty()) {
            return null;
        }
        return list.get(0);
    }

    @Override
    public List<KhoaHoc> selectBySql(String sql, Object... args) {
        List<KhoaHoc> list = new ArrayList<>();
         SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy"); 
        try {
            ResultSet rs = JdbcHelper.query(sql, args);
            while (rs.next()) {                
                KhoaHoc entity = new KhoaHoc();
                entity.setMaKH(Integer.parseInt(rs.getString("MaKH")));
                entity.setMaCD(rs.getString("MaCD"));
                entity.setHocPhi(Double.parseDouble(rs.getString("HocPhi")));
                entity.setThoiLuong(Integer.parseInt(rs.getString("ThoiLuong")));
                entity.setNgayKG(formatter.parse(rs.getString("NgayKG")));
                entity.setGhiChu(rs.getString("GhiChu"));
                entity.setMaNV(rs.getString("MaNV"));
                entity.setNgayTao(formatter.parse(rs.getString("NgayTao")));
                list.add(entity);
            }
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        return list;
    }
    
}

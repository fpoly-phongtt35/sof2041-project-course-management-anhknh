/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edusys_dao;

import edusys_entity.HocVien;
import edusys_utils.JdbcHelper;
import java.util.ArrayList;
import java.util.List;
import java.sql.ResultSet;

/**
 *
 * @author Admin
 */
public class HocVienDAO extends EduSysDAO<HocVien, Integer>{
    final String INSERT_SQL = "INSERT INTO HOCVIEN(MAHV, MAKH, MANH, DIEM) VALUES(?,?,?,?)";
    final String UPDATE_SQL = "UPDATE HOCVIEN SET MAKH = ?, MANH = ?, DIEM = ? WHERE MAHV = ?";
    final String DELETE_SQL = "DELETE FROM HOCVIEN WHERE MAHV = ?";
    final String SELECT_ALL_SQL = "SELECT * FROM HOCVIEN";
    final String SELECT_BY_ID_SQL = "SELECT * FROM HOCVIEN WHERE MAHV = ?";
    @Override
    public void insert(HocVien entity) {
        JdbcHelper.update(INSERT_SQL, entity.getMaHV(), entity.getMaKH(), entity.getMaNH(), entity.getDiem());
    }

    @Override
    public void update(HocVien entity) {
        JdbcHelper.update(UPDATE_SQL, entity.getMaKH(), entity.getMaNH(), entity.getDiem(), entity.getMaHV());
    }

    @Override
    public void delete(Integer id) {
        JdbcHelper.update(DELETE_SQL, id);
    }

    @Override
    public List<HocVien> selectAll() {
        return selectBySql(SELECT_ALL_SQL);
    }

    @Override
    public HocVien selectById(Integer id) {
        List<HocVien> list = selectBySql(SELECT_BY_ID_SQL, id);
        if(list.isEmpty()){
            return null;
        }
        return list.get(0);
    }

    @Override
    public List<HocVien> selectBySql(String sql, Object... args) {
        List<HocVien> list = new ArrayList<>();
        try {
            ResultSet rs = JdbcHelper.query(sql, args);
            while (rs.next()) {                
                HocVien entity = new HocVien();
                entity.setMaHV(Integer.parseInt(rs.getString("MaHV")));
                entity.setMaKH(Integer.parseInt(rs.getString("MaKH")));
                entity.setMaNH(rs.getString("MaNH"));
                entity.setDiem(Double.parseDouble(rs.getString("Diem")));
                list.add(entity);
            }
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        return list;
    }
    
}

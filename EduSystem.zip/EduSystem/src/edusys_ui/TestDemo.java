/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package edusys_ui;

import edusys_dao.NhanVienDAO;
import edusys_entity.NhanVien;
import java.util.List;

/**
 *
 * @author Admin
 */
public class TestDemo {
    public static void main(String[] args) {
        NhanVienDAO dao = new NhanVienDAO();
        //dao.insert(new NhanVien("NV0002", "Trần Diễm Quỳnh", "234567", "Nhân Viên"));
        List<NhanVien> list = dao.selectAll();
        for (NhanVien nhanVien : list) {
            System.out.println("=>" +nhanVien.toString());
        }
    }
}
